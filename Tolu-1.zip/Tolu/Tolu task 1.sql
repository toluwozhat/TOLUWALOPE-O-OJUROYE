use	hospital_dbms
Go 

-- Creating the Departments table
CREATE TABLE Departments (
    DepartmentID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL
);

-- Creating the Doctors table
CREATE TABLE Doctors (
    DoctorID INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(255) NOT NULL,
    DepartmentID INT NOT NULL,
    Specialty NVARCHAR(100) NOT NULL,
    CONSTRAINT fk_Department FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
);

-- Creating the Patients table
CREATE TABLE Patients (
    PatientID INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(255) NOT NULL,
    Address NVARCHAR(255) NOT NULL,
    DateOfBirth DATE NOT NULL,
    Insurance NVARCHAR(100) NOT NULL,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(50) NOT NULL,
    Email NVARCHAR(100),
    Telephone NVARCHAR(15),
    LeftDate DATE
);

-- Creating the MedicalRecords table
CREATE TABLE MedicalRecords (
    RecordID INT IDENTITY(1,1) PRIMARY KEY,
    PatientID INT NOT NULL,
    Diagnoses NVARCHAR(MAX) NOT NULL,
    Medicines NVARCHAR(MAX) NOT NULL,
    PrescribedDate DATE NOT NULL,
    Allergies NVARCHAR(MAX),
    CONSTRAINT fk_Patient FOREIGN KEY (PatientID) REFERENCES Patients(PatientID)
);

-- Creating the Appointments table with a check constraint on the Date to ensure it's not in the past
CREATE TABLE Appointments (
    AppointmentID INT IDENTITY(1,1) PRIMARY KEY,
    PatientID INT NOT NULL,
    DoctorID INT NOT NULL,
    Date DATE NOT NULL,
    Time TIME NOT NULL,
    DepartmentID INT NOT NULL,
    Status NVARCHAR(50) NOT NULL,
    CONSTRAINT fk_PatientAppointment FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    CONSTRAINT fk_DoctorAppointment FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID),
    CONSTRAINT fk_DepartmentAppointment FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID),
    CONSTRAINT chk_AppointmentDate CHECK (Date >= CAST(GETDATE() AS DATE))
);


-- insert records into departments table 
INSERT INTO Departments (Name) VALUES 
('Cardiology'),
('Oncology'),
('Pediatrics'),
('Neurology'),
('Orthopedics'),
('Gastroenterology'),
('Dermatology');

-- fetch the department records 
select * from dbo.Departments

-- Insert records into Doctors table
INSERT INTO Doctors (FullName, DepartmentID, Specialty) VALUES 
('Dr. Alice Smith', 1, 'Endocrinologist'),
('Dr. Bob Johnson', 2, 'Neurologist'),
('Dr. Carol Sanveee', 3, 'Pediatrician'),
('Dr. Israel Scott', 4, 'Neurologist'),
('Dr. Erica Stone', 5, 'Orthopedist'),
('Dr. Frank Judah', 6, 'Gastroenterologist'),
('Dr. Grace Xavi', 7, 'Dermatologist');

-- check docs
select * from dbo.Doctors

-- Insert records into Patients table, ensuring some patients are over 40 and have cancer
INSERT INTO Patients 
(FullName, Address, DateOfBirth, Insurance, Username, Password, Email, Telephone, LeftDate) 
VALUES 
('John Doe', '111 Maple St', '1976-04-15', 'SuperCare', 'jdoe', 'jdpass123', 'john.doe@gmail.com', '555-0101', '2024-01-15'),
('Jane Smith', '222 Oak St', '1968-08-23', 'PrimeHealth', 'jsmith', 'jspass456', 'jane.smith@yahoomail.com', '555-0202', '2024-02-20'),
('Michael Johnson', '333 Pine Lane', '1955-05-10', 'HealthPlus', 'mjohnson', 'mjohnpass789', 'michael.johnson@hotmail.com', '555-0303', '2024-03-30'),
('Karen Brown', '444 Cedar Blvd', '1971-12-01', 'WellnessCore', 'kbrown', 'kbpass1010', 'karen.brown@gmail.com', '555-0404', '2024-04-25'),
('Laura Wilson', '555 Birch Road', '1959-09-28', 'CareMax', 'lwilson', 'lwpass1111', 'laura.wilson@yahoomail.com', '555-0505', '2024-05-05'),
('Robert Lee', '666 Willow St', '1972-04-18', 'UltimaHealth', 'rlee', 'rlpass2222', 'robert.lee@hotmail.com', '555-0606', '2024-06-15'),
('Emma Taylor', '777 Cedar Way', '1965-11-25', 'HealthGuard', 'etaylor', 'etpass3333', 'emma.taylor@gmail.com', '555-0789', '2024-07-22');



select * from dbo.Patients

-- Insert records into MedicalRecords table, including Cancer diagnoses for some patients over 40
INSERT INTO MedicalRecords (PatientID, Diagnoses, Medicines, PrescribedDate, Allergies) VALUES 
(1, 'Asthma', 'Albuterol', '2024-04-12', 'Dust'),
(2, 'Epilepsy', 'Levetiracetam', '2024-05-18', 'Iodine'),
(4, 'Cancer', 'Hormone Therapy', '2024-06-14', 'Pollen'),
(3, 'Chronic Kidney Disease', 'Epoetin Alfa', '2024-07-20', 'Dairy'),
(5, 'Psoriasis', 'Adalimumab', '2024-08-25', 'Gluten'),
(7, 'Cancer', 'Targeted Therapy', '2024-09-05', 'Bee Stings'),
(6, 'Anemia', 'Iron Supplements', '2024-10-04', 'Wheat');


select * from dbo.MedicalRecords

-- Insert records into Appointments table, ensuring some are with Gastroenterologists and some are completed
INSERT INTO Appointments (PatientID, DoctorID, Date, Time, DepartmentID, Status) VALUES 
(1, 1, '2024-08-15', '10:00:00', 1, 'Scheduled'),
(2, 2, '2024-08-16', '11:00:00', 2, 'canclled'),
(3, 3, '2024-08-17', '09:00:00', 3, 'Scheduled'),
(4, 4, '2024-08-18', '14:00:00', 4, 'Scheduled'),
(5, 6, '2024-08-19', '15:00:00', 6, 'Cancelled'), 
(6, 6, '2024-08-20', '13:00:00', 6, 'Completed'),
(7,5, '2024-08-21','13:00:00',6, 'Completed')
-- check appointment 
select * from dbo.Appointments


-- Question 2a.	List all the patients with older than 40 and have Cancer in diagnosis. 
SELECT p.PatientID, p.FullName
FROM dbo.Patients p
JOIN dbo.MedicalRecords mr ON p.PatientID = mr.PatientID
WHERE DATEDIFF(year, p.DateOfBirth, GETDATE()) > 40
  AND mr.Diagnoses LIKE '%Cancer%';


 
 -- 3a)	Search the database of the hospital for matching character strings by name of medicine. Results should be sorted with most recent medicine prescribed date first.  
  CREATE PROCEDURE SearchMedicine
    @MedicineName NVARCHAR(100)
AS
BEGIN
    SELECT PatientID, Diagnoses, Medicines, PrescribedDate, Allergies
    FROM dbo.MedicalRecords
    WHERE Medicines LIKE '%' + @MedicineName + '%'
    ORDER BY PrescribedDate DESC;
END;

-- Execute 3a task 
EXEC SearchMedicine @MedicineName = 'Adalimumab';




-- 3b  
CREATE FUNCTION GetDiagnosisAndAllergiesForTodayAppointments (@PatientID INT)
RETURNS TABLE
AS
RETURN (
    SELECT Diagnoses, Allergies
    FROM dbo.MedicalRecords
    WHERE PatientID = @PatientID
    AND EXISTS (
        SELECT 1
        FROM dbo.Appointments
        WHERE PatientID = @PatientID
        AND CAST(Date AS DATE) = CAST(GETDATE() AS DATE)
    )
);

-- check the function to get diagnosis and allergies
SELECT * FROM GetDiagnosisAndAllergiesForTodayAppointments(1);


-- 3c)	Update the details for an existing doctor 
CREATE PROCEDURE UpdateDoctorDetails
    @DoctorID INT,
    @FullName NVARCHAR(255),
    @DepartmentID INT,
    @Specialty NVARCHAR(100)
AS
BEGIN
    UPDATE Doctors
    SET FullName = @FullName,
        DepartmentID = @DepartmentID,
        Specialty = @Specialty
    WHERE DoctorID = @DoctorID;
END;
EXEC UpdateDoctorDetails @DoctorID = 2, @FullName = 'Dr.Olu Jacobs', @DepartmentID = 2, @Specialty = 'Dentist';

select * from dbo. Doctors



CREATE PROCEDURE DeleteCompletedAppointments
AS
BEGIN
    DELETE FROM Appointments
    WHERE Status = 'Completed';
END;

EXEC DeleteCompletedAppointments;

-- task 4 create a view for appointment
CREATE VIEW v_AppointmentDetails AS
SELECT 
    a.AppointmentID,
    a.Date AS AppointmentDate,
    a.Time AS AppointmentTime,
    d.FullName AS DoctorName,
    d.Specialty,
    dep.Name AS DepartmentName
FROM Appointments a
JOIN Doctors d ON a.DoctorID = d.DoctorID
JOIN Departments dep ON d.DepartmentID = dep.DepartmentID;

-- task 4: get the appointment view result 
SELECT * FROM v_AppointmentDetails
ORDER BY AppointmentDate DESC, AppointmentTime DESC;

-- 5 trigger task 
CREATE TRIGGER UpdateAppointmentToAvailable_trg
ON Appointments
AFTER UPDATE
AS
BEGIN
    -- Check if there is a change to the 'Status' column to 'Cancelled'
    IF UPDATE(Status)
    BEGIN
        -- Update the status to 'Available' for the rows that were changed to 'Cancelled'
        UPDATE a
        SET a.Status = 'Available'
        FROM Appointments a
        JOIN inserted i ON a.AppointmentID = i.AppointmentID
        JOIN deleted d ON i.AppointmentID = d.AppointmentID
        WHERE i.Status = 'Cancelled' AND d.Status <> 'Cancelled';
    END
END;

-- check the result 
UPDATE Appointments
SET Status = 'Cancelled'
WHERE AppointmentID = 2

select * from Appointments

update Appointments
set Status = 'Completed' 
where DoctorID = 6

-- task 6: query which allows the hospital to identify the number of completed appointments with the specialty of doctors as �Gastroenterologists�
SELECT COUNT(a.AppointmentID) AS NumberOfCompletedAppointments
FROM Appointments a
JOIN Doctors d ON a.DoctorID = d.DoctorID
WHERE d.Specialty = 'Gastroenterologist'
AND a.Status ='Completed'; 



