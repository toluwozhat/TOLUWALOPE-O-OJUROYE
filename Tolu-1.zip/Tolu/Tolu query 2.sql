use [FoodserviceDB ]
go 


-- task 2 part 2 
-- ques 1.	Write a query that lists all restaurants with a Medium range price with open area, serving Mexican food.  
SELECT  r.Name, r.City, r.State, r.Country
FROM dbo.Restaurant r
INNER JOIN Restaurant_cuisines rc ON r.Restaurant_ID = rc.Restaurant_ID
WHERE r.Price = 'Medium'
AND r.Area = 'Open'
AND rc.Cuisine = 'Mexican';

-- ques 2.	Write a query that returns the total number of restaurants who have the overall rating as 1 and are serving Mexican food. Compare the results with the total number of restaurants who have the overall rating as 1 serving Italian food 
SELECT COUNT(DISTINCT rat.Restaurant_ID) AS TotalRestaurantsWithRating1_Mexican
FROM Ratings rat
JOIN Restaurant_cuisines rc ON rat.Restaurant_ID = rc.Restaurant_ID
WHERE rat.Overall_Rating = 1
AND rc.Cuisine = 'Mexican';

SELECT COUNT(DISTINCT rat.Restaurant_ID) AS TotalRestaurantsWithRating1_Italian
FROM Ratings rat
JOIN Restaurant_cuisines rc ON rat.Restaurant_ID = rc.Restaurant_ID
WHERE rat.Overall_Rating = 1
AND rc.Cuisine = 'Italian';

-- Ques 3.	Calculate the average age of consumers who have given a 0 rating to the 'Service_rating' column. 

SELECT ROUND(AVG(CAST(c.Age AS FLOAT)), 0) AS AverageAge
FROM Consumers c
JOIN Ratings r ON c.Consumer_ID = r.Consumer_ID
WHERE r.Service_Rating = 0;

-- Ques 4:	Restaurant ranking
SELECT 
    res.Name AS RestaurantName,
    youngRatings.Food_Rating
FROM (
    SELECT 
        r.Restaurant_ID,
        r.Food_Rating,
        RANK() OVER (PARTITION BY r.Restaurant_ID ORDER BY c.Age ASC) as Rank
    FROM Ratings r
    INNER JOIN Consumers c ON r.Consumer_ID = c.Consumer_ID
) AS youngRatings
INNER JOIN Restaurant res ON youngRatings.Restaurant_ID = res.Restaurant_ID
WHERE youngRatings.Rank = 1
ORDER BY youngRatings.Food_Rating DESC;

-- Ques 5: Update the Service_rating of all restaurants to '2' if they have parking available, either as 'yes' or 'public' 

CREATE PROCEDURE UpdateServiceRatingForParking
AS
BEGIN
    -- Update the Service_rating to '2' for restaurants with available parking
    UPDATE rat
    SET Service_Rating = 2
    FROM Ratings rat
    INNER JOIN Restaurant res ON rat.Restaurant_ID = res.Restaurant_ID
    WHERE res.Parking IN ('yes', 'public');
END;

EXEC UpdateServiceRatingForParking;

select * from [Restaurant ]

-- other queries 4
-- query 1 Identify restaurants with the most frequent high food ratings (2) using EXISTS.
SELECT 
    r.Name, 
    COUNT(*) AS NumberOfRatings
FROM 
    Restaurant r
WHERE 
    EXISTS (
        SELECT 1 
        FROM Ratings rat 
        WHERE rat.Restaurant_ID = r.Restaurant_ID
    )
GROUP BY 
    r.Name
ORDER BY 
    NumberOfRatings DESC;

	-- query 2: Find cuisines that have never received a perfect overall rating of 5 using a nested NOT IN query.
	SELECT 
    c.Consumer_ID, 
    c.City, 
    c.Age
FROM 
    Consumers c
WHERE 
    c.Consumer_ID IN (
        SELECT DISTINCT rat.Consumer_ID 
        FROM Ratings rat 
        WHERE rat.Food_Rating <= 4
    )
ORDER BY 
    c.City, 
    c.Age;

	-- query 3:Query to List Cities with Average Food Ratings Lower Than 2
	SELECT 
    c.City, 
    AVG(r.Food_Rating) AS AverageFoodRating
FROM 
    Consumers c
JOIN 
    Ratings r ON c.Consumer_ID = r.Consumer_ID
GROUP BY 
    c.City
HAVING 
    AVG(r.Food_Rating) < 2
ORDER BY 
    AverageFoodRating DESC;

--query 4:Query for Average Age by City with a Minimum of Six Consumers, Ordered by Youngest Average Age

SELECT City, ROUND(AVG(CAST(Age AS FLOAT)), 0) AS AverageAge
FROM Consumers
GROUP BY City
HAVING COUNT(*) > 5 
ORDER BY AverageAge ASC;












